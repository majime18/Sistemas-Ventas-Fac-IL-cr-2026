CXP ULTRA-COMPAT (estilo CXC)
- Corrige error de proveedores sin 'cedula'.
- Detecta: proveedores.cedula / identificacion / numero_identificacion (si existen).
- Detecta: cxp_documentos.numero_documento / numero / documento (si existen).
- No requiere cambios en BD para funcionar.
Opcional: SQL_patch_cxp_ultracompat.sql para agregar columnas pro.
